-- pyright
local shared = require("shared")

vim.lsp.config("pyright", {
	on_attach = shared.on_attach,
	capabilities = shared.capabilities,
	settings = {
		python = {
			analysis = {
				typeCheckingMode = "basic", -- or 'strict'
				autoImportCompletions = true,
			},
		},
	},
})
